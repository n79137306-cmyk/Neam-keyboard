package com.neam.keyboard

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface

class Bridge(
    private val ctx: Context,
    private val ime: Boolean = false,
    private val ic: () -> InputConnection? = { null },
    private val onResize: (Int) -> Unit = {}
) {
    private val ui = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("kb", Context.MODE_PRIVATE)

    @JavascriptInterface fun saveTheme(s: String) { prefs.edit().putString("theme", s).apply() }
    @JavascriptInterface fun isIme(): Boolean = ime
    @JavascriptInterface fun getTheme(): String = prefs.getString("theme", "") ?: ""
    @JavascriptInterface fun commit(s: String) { ui.post { ic()?.commitText(s, 1) } }
    @JavascriptInterface fun del() {
        ui.post {
            val c = ic() ?: return@post
            val sel = c.getSelectedText(0)
            if (sel != null && sel.isNotEmpty()) c.commitText("", 1) else c.deleteSurroundingText(1, 0)
        }
    }
    @JavascriptInterface fun enter() {
        ui.post {
            val c = ic() ?: return@post
            c.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            c.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }
    @JavascriptInterface fun resize(cssPx: Int) {
        ui.post { onResize((cssPx * ctx.resources.displayMetrics.density).toInt()) }
    }
    @JavascriptInterface fun enableIme() {
        ctx.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    @JavascriptInterface fun pickIme() {
        (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }
}
