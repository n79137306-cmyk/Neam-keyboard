package com.neam.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebView

class KeyboardService : InputMethodService() {
    private var web: WebView? = null

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.setBackgroundColor(0)
        w.isLongClickable = false
        w.addJavascriptInterface(Bridge(this, { currentInputConnection }) { h ->
            w.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            w.requestLayout()
        }, "Android")
        w.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, (260 * resources.displayMetrics.density).toInt())
        w.loadUrl("file:///android_asset/keyboard.html?mode=ime")
        web = w
        return w
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        web?.evaluateJavascript("window.refresh&&refresh()", null)
    }
}
