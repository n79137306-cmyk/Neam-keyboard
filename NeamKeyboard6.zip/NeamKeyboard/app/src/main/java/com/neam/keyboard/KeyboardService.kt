package com.neam.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.widget.FrameLayout

class KeyboardService : InputMethodService() {
    private var web: WebView? = null

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        val d = resources.displayMetrics.density
        val root = FrameLayout(this)
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.setBackgroundColor(0)
        w.isLongClickable = false
        w.addJavascriptInterface(Bridge(this, { currentInputConnection }) { h ->
            if (h > (80 * d).toInt()) {
                val lp = w.layoutParams as FrameLayout.LayoutParams
                lp.height = h
                w.layoutParams = lp
            }
        }, "Android")
        root.addView(w, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (260 * d).toInt()))
        w.loadUrl("file:///android_asset/keyboard.html?mode=ime")
        web = w
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        web?.evaluateJavascript("window.refresh&&refresh()", null)
    }
}
